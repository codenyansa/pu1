$(document).ready(function() {

  $(function() {
    $('.headline').glitch({
      minint: 1,
      maxint: 3,
      maxglitch: 15,
      hoffset: 10,
      voffset: 3
    });
  });

  $(function() {
    $('.close').glitch({
      minint: 1,
      maxint: 3,
      maxglitch: 15,
      hoffset: 10,
      voffset: 3
    });
  });

  // Word Matrix
  var text = $('.confused_text_input').val(),
    words = text.split(' ');

  // Output
  words.forEach(function(word, index) {

    var eachWord = $('<span></span>').text(word).append(" ");;
    $('.confused_text_output').append(eachWord);

    // // Random Order
    // var order = $(".confused_text_output span");
    // for(var i = 0; i < order.length; i++){
    //   var target = Math.floor(Math.random() * order.length -1) + 1;
    //   var target2 = Math.floor(Math.random() * order.length -1) +1;
    //   order.eq(target).before(order.eq(target2));
    // }

  });

  // Random Postion of span
  function radomPosition() {
    $('.confused_text_output span').each(function(element, index) {
      // Random Top
      Number.random = function(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
      };
      var randomNumberTop = Number.random(1, $(window).height());

      // Radom Left
      Number.random = function(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
      };
      var randomNumberLeft = Number.random(1, $(window).width());

      $(this).css({
        'top': randomNumberTop,
        'left': randomNumberLeft
      });

    });
  }

  // Fires random words
  function checkWords() {
    if ($('#articles .item').hasClass('center')) {
      var interval = setInterval(
        function() {
          $('.confused_text_output span').each(function(i) {
            radomPosition();
            $(this).delay(5000 * i).fadeIn(100);
            $(this).delay(500 * i).fadeOut(100);
          });
        }, 1000);
    }
  }

  checkWords();

  // Dynamic picture
  function RandomImageProp() {

    // Random perspective
    Number.random = function(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    };
    var randomNumberPerspective = Number.random(80, 120);

    // Random perspective extreme
    Number.random = function(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    };
    var randomNumberPerspectiveExtreme = Number.random(100, 160);

    // Random rotateX
    Number.random = function(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    };
    var randomNumberRotateX = Number.random(-5, 5);

    // Random rotateY
    Number.random = function(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    };
    var randomNumberRotateY = Number.random(-5, 5);

    // Pass value to css
    $('#dynamicImage').css({
      perspective: randomNumberPerspective,
      rotateX: randomNumberRotateX,
      rotateY: randomNumberRotateY
    });

    $('#dynamicImageBg').css({
      perspective: randomNumberPerspectiveExtreme,
      rotateX: randomNumberRotateY,
      rotateY: randomNumberRotateX
    });

  }

  RandomImageProp();

  // RandomBg
  function RandomBg() {

    // Random perspective extreme
    Number.random = function(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    };
    var randomNumberPerspectiveExtreme = Number.random(100, 160);

    // Random rotateX
    Number.random = function(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    };
    var randomNumberRotateX = Number.random(-5, 5);

    // Random rotateY
    Number.random = function(min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min);
    };
    var randomNumberRotateY = Number.random(-5, 5);

    $('#dynamicImageBg').css({
      perspective: randomNumberPerspectiveExtreme,
      rotateX: randomNumberRotateY,
      rotateY: randomNumberRotateX
    });
  }


  $(window).scroll(function() {
    if ($(window).scrollTop() > 500) {
      RandomBg();
    }
  });

  // // Random Text
  // function RandomText() {
  //
  //   // Random perspective extreme
  //   Number.random = function(min, max) {
  //     return Math.floor(Math.random() * (max - min + 1) + min);
  //   };
  //   var randomNumberPerspectiveExtreme = Number.random(50, 160);
  //
  //   // Random rotateX
  //   Number.random = function(min, max) {
  //     return Math.floor(Math.random() * (max - min + 1) + min);
  //   };
  //   var randomNumberRotateX = Number.random(-5, 5);
  //
  //   // Random rotateY
  //   Number.random = function(min, max) {
  //     return Math.floor(Math.random() * (max - min + 1) + min);
  //   };
  //   var randomNumberRotateY = Number.random(-5, 5);
  //
  //   var items = $('.content-wrapper section');
  //
  //   $('.content-wrapper section').each(function(i) {
  //     $(this).delay(100 * i).css({
  //       perspective: randomNumberPerspectiveExtreme,
  //       rotateX: randomNumberRotateY,
  //       rotateY: randomNumberRotateX
  //     });
  //   });
  //
  // }
  //
  // RandomText();

  // Random Order


  // Article counter

  var $article_total = $('#articles .item').length;
  $('.total').text($article_total);

  function currentCount() {
    $article_current = $('.item.center').index() + 1;
    $('.current').text($article_current);
  }

  currentCount();

  // Article selection wheel

  var $article_steps = $('#articles .item');
  var $dynamicImage_steps = $('#dynamicImage .item');

  function nextArticle(e) {

    // check if scroll next and add class to body
    if ($('#body').hasClass('scroll_prev')) {
      $('#body').removeClass('scroll_prev');
      $('#body').addClass('scroll_next');
    } else {
      $('#body').addClass('scroll_next');
    }

    // article steps
    var $next = $article_steps.filter('.center').removeClass('center').next('#articles .item');
    var $nextbefore = $article_steps.filter('.before').removeClass('before').next('#articles .item');
    var $nextafter = $article_steps.filter('.after').removeClass('after').next('#articles .item');

    if (!$next.length) $next = $article_steps.first(); {
      $next.addClass('center');
      currentCount();
    }
    if (!$nextbefore.length) $nextbefore = $article_steps.first(); {
      $nextbefore.addClass('before');
    }
    if (!$nextafter.length) $nextafter = $article_steps.first(); {
      $nextafter.addClass('after');
    }

    // dynamicImage steps
    var $image_next = $dynamicImage_steps.filter('.center').removeClass('center').next('#dynamicImage .item');
    var $image_nextbefore = $dynamicImage_steps.filter('.before').removeClass('before').next('#dynamicImage .item');
    var $image_nextafter = $dynamicImage_steps.filter('.after').removeClass('after').next('#dynamicImage .item');

    if (!$image_next.length) $image_next = $dynamicImage_steps.first(); {
      $image_next.addClass('center');
    }
    if (!$image_nextbefore.length) $image_nextbefore = $dynamicImage_steps.first(); {
      $image_nextbefore.addClass('before');
    }
    if (!$image_nextafter.length) $image_nextafter = $dynamicImage_steps.first(); {
      $image_nextafter.addClass('after');
    }

    RandomImageProp();

  }

  function prevArticle(e) {

    // check if scroll prev and add class to body
    if ($('#body').hasClass('scroll_next')) {
      $('#body').removeClass('scroll_next');
      $('#body').addClass('scroll_prev');
    } else {
      $('#body').addClass('scroll_prev');
    }

    // article steps
    var $prev = $article_steps.filter('.center').removeClass('center').prev('#articles .item');
    var $prevbefore = $article_steps.filter('.before').removeClass('before').prev('#articles .item');
    var $prevafter = $article_steps.filter('.after').removeClass('after').prev('#articles .item');

    if (!$prev.length) $prev = $article_steps.last(); {
      $prev.addClass('center');
      currentCount();
    }
    if (!$prevbefore.length) $prevbefore = $article_steps.last(); {
      $prevbefore.addClass('before');
    }
    if (!$prevafter.length) $prevafter = $article_steps.last(); {
      $prevafter.addClass('after');
    }

    // dynamicImage steps
    var $image_prev = $dynamicImage_steps.filter('.center').removeClass('center').prev('#dynamicImage .item');
    var $image_prevbefore = $dynamicImage_steps.filter('.before').removeClass('before').prev('#dynamicImage .item');
    var $image_prevafter = $dynamicImage_steps.filter('.after').removeClass('after').prev('#dynamicImage .item');

    if (!$image_prev.length) $image_prev = $dynamicImage_steps.last(); {
      $image_prev.addClass('center');
    }
    if (!$image_prevbefore.length) $image_prevbefore = $dynamicImage_steps.last(); {
      $image_prevbefore.addClass('before');
    }
    if (!$image_prevafter.length) $image_prevafter = $dynamicImage_steps.last(); {
      $image_prevafter.addClass('after');
    }

    RandomImageProp();

  }

  // Fires article scroll
  function articleScroll() {
    $('#articles-wrapper').scrollsteps({
      up: prevArticle,
      down: nextArticle
    });
  }

  // Check if article is open
  $(body).click(function() {
    if ($(body).hasClass('article-open')) {
      $(body).removeClass('article-open');
      RandomBg();
      $('#articles-wrapper').bind(articleScroll());
    } else {
      $(body).addClass('article-open');
      RandomBg();
      $('#articles-wrapper').unbind(articleScroll());
    }
  });

  articleScroll();

  // Category selection wheel
  var $category_steps = $('#category .item');

  function nextCategory(e) {
    var $next = $category_steps.filter('.active').removeClass('active').next('#category .item');
    var $nextout = $category_steps.filter('.out').removeClass('out').next('#category .item');
    if (!$next.length) $next = $category_steps.first(); {
      $next.addClass('active');
    }
    if (!$nextout.length) $nextout = $category_steps.first(); {
      $nextout.addClass('out');
    }
  }

  function prevCategory(e) {
    var $prev = $category_steps.filter('.active').removeClass('active').prev('#category .item');
    var $prevout = $category_steps.filter('.out').removeClass('out').prev('#category .item');
    if (!$prev.length) $prev = $category_steps.last(); {
      $prev.addClass('active');
    }
    if (!$prevout.length) $prevout = $category_steps.last(); {
      $prevout.addClass('out');
    }
  }

  $('#category').scrollsteps({
    up: prevCategory,
    down: nextCategory
  });

  var rellax = new Rellax('.rellax');

  // $(function() {
  //   $(".intro").on('mousewheel DOMMouseScroll', function(event, delta) {
  //     this.scrollLeft -= (delta * 0.5);
  //     event.preventDefault();
  //   });
  // });
  //
  // $(".intro").hover(
  //   function() {
  //     $(".back").toggleClass("intro_hover")
  //   }
  // );

  (function($) {

    /**
     * Copyright 2012, Digital Fusion
     * Licensed under the MIT license.
     * http://teamdf.com/jquery-plugins/license/
     *
     * @author Sam Sehnert
     * @desc A small plugin that checks whether elements are within
     *     the user visible viewport of a web browser.
     *     only accounts for vertical position, not horizontal.
     */

    $.fn.visible = function(partial) {

      var $t = $(this),
        $w = $(window),
        viewTop = $w.scrollTop(),
        viewBottom = viewTop + $w.height() - 300,
        _top = $t.offset().top,
        _bottom = _top + $t.height(),
        compareTop = partial === true ? _bottom : _top,
        compareBottom = partial === true ? _top : _bottom;

      return ((compareBottom <= viewBottom) && (compareTop >= viewTop));

    };

  })(jQuery);

  $(window).scroll(function(event) {

    $("section, .back").each(function(i, el) {
      var el = $(el);
      if (el.visible(true)) {
        el.addClass("highlight-1").delay(200);
      } else {
        el.removeClass("highlight-1").delay(200);
      }
    });

  });

});