var app = angular.module('fileUploadApp', []);
app.controller('fileUploadCtrl', function($scope, $http, $location) {
   console.log("hi controller Angular");
   $scope.success = false;
   $scope.error = false;
   
   $scope.fileupload=function()
   {
	   var form = $scope.filedetailform;
	   var frm = new FormData();
	   
	   frm.append('filename', fileName);
	   frm.append('filedetails',fileDetails);
	   frm.append('id',id);
	   frm.append('photo',form.photo.file[0]);
	   
	   angular.forEach(form.attatched_file,function(file,key)
	   var file_name = 'attatched_file'+key;
	   frm.append(fileName, file);
       
   });
   
   
 }