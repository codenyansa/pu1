var app = angular.module('testApp', []);
app.controller('testeventCtrl', function($scope, $http, $location) {
   console.log("hi controller Angular");
   $scope.success = false;
   $scope.error = false;
   
   function fetchData()
   {
		  console.log("in fetchData() event");
		   $scope.eventList = [];
		   var url = 'getEventTestList';
			
			var config = {
	               headers : {
	                   'Content-Type': 'application/json;charset=utf-8;'
	               }
	       }
			$http.get(url).then(function (response) {
				//$scope.getDivAvailable = true;
				$scope.eventList = response.data;
				console.log(response.data);
			}, function error(response) {
				$scope.postResultMessage = "Error Status: " +  response.statusText;
			});
		  
		  }
	   fetchData();
   
	  $scope.submitForm = function(){
		  var url = "addTestevent";
			
			var config = {
	                headers : {
	                    'Content-Type': 'application/json;charset=utf-8;'
	                }
	        }
			
			var data = {
					event_title: $scope.event_title,
					event_details:$scope.event_details,
					dateOfInsert: $scope.dateOfInsert,
					start_time: $scope.start_time,
					end_time: $scope.end_time,
					image1: $scope.image1,
					image2: $scope.image2,
					
	        };
			
			
			$http.post(url, data, config).then(function (response) {
				 $scope.success = true;
				    $scope.error = false;
				    $scope.successMessage = 'successful';
				    $scope.form_data = {};
				    console.log('done');
			}, function (response) {
				 $scope.success = false;
				    $scope.error = true;
				    $scope.errorMessage = 'error...!';
			});
			
			
	  }
	  
});