app.controller('indexCtrl', function($scope, $http, $location) {
   console.log("hi paresh");
   $scope.success = false;
   $scope.error = false;
   function fetchData(){
	   $scope.catsData = [];
	   var url = 'allCat';
		
		var config = {
               headers : {
                   'Content-Type': 'application/json;charset=utf-8;'
               }
       }
		$http.get(url).then(function (response) {
			//$scope.getDivAvailable = true;
			$scope.catsData = response.data;
			console.log(response.data);
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " +  response.statusText;
		});
	  /*  $http.get(url, config).then(function(response) {
		   
			if (response.data.status == "Done") {
				$scope.catsData = response.data;
				console.log("successs!");
				console.log(response.data);
				//console.log(response.categorys);
				//$scope.showAllCustomers = true;

			} else {
				console.log("get All Customers Data Error!");
			}

		}, function(response) {
			console.log("Fail!");
		}); */
	  }
   fetchData();
   function getSelecteIndex(ids)
   {
	   for(var i=0; i < $scope.catsData.length ; i++)
	   if($scope.catsData.length[i].id == ids)
		   return i;
	   return -1;
   }
   $scope.editCat = function(id)
   {
	 // var index = getSelecteIndex(id);
	  //console.log(index);
	   var cat = $scope.catsData[id];
	   $scope.modalTitle = 'Update Category';
	   $scope.submit_button = 'Update';
	   $scope.catName = cat.catname;
	   $scope.catDesc = cat.catdesc;
	   $scope.hidden_id = cat.id;
	   var modal_popup = angular.element('#updatemodal');
	   modal_popup.modal('show');
   };
	  
	  
   $scope.openModal = function(){
	   var modal_popup = angular.element('#crudmodal');
	   modal_popup.modal('show');
	  }

   $scope.closeModal = function(){
	  var modal_popup = angular.element('.crudmodal');
	  modal_popup.modal('hide');
	  }
	  
	  $scope.addData = function(){
		  $scope.modalTitle = 'Create Category';
		  $scope.submit_button = 'Insert';
		  $scope.openModal();
		 };
		 
		
			 $scope.deleteData = function(id){
				  if(confirm("Are you sure you want to remove it?"))
				  {
					  
					  var url = "/category/"+id;
					  $http.post(url).then(function (response) {
							 $scope.success = true;
							    $scope.error = false;
							    $scope.successMessage = 'successful';
							    //$scope.form_data = {};
							    console.log('done');
							    $scope.closeModal();
							    fetchData();
						}, function (response) {
							 $scope.success = false;
							    $scope.error = true;
							    $scope.errorMessage = 'error...!';
						});
			/* 	   $http({
				    method:"POST",
				    url:" /category/"+id
				   }),success(function(data){
				    $scope.success = true;
				    $scope.error = false;
				    $scope.successMessage = data.message;
				    fetchData();
				   }); */
				  }
				 };
	  $scope.submitForm = function(){
		  var url = "postcategory";
			
			var config = {
	                headers : {
	                    'Content-Type': 'application/json;charset=utf-8;'
	                }
	        }
			
			var data = {
					catname: $scope.catName,
					catdesc: $scope.catDesc
	        };
			
			
			$http.post(url, data, config).then(function (response) {
				 $scope.success = true;
				    $scope.error = false;
				    $scope.successMessage = 'successful';
				    $scope.form_data = {};
				    console.log('done');
				    $scope.closeModal();
				    fetchData();
			}, function (response) {
				 $scope.success = false;
				    $scope.error = true;
				    $scope.errorMessage = 'error...!';
			});
			
			$scope.firstname = "";
			$scope.lastname = "";
	  }
	  
	  $scope.updateForm = function(){
		  var url = "updatecategory/"+$scope.hidden_id;
			
			var config = {
	                headers : {
	                    'Content-Type': 'application/json;charset=utf-8;'
	                }
	        }
			
			var data = {
					id: $scope.hidden_id,
					catname: $scope.catName,
					catdesc: $scope.catDesc
	        };
			
			
			$http.post(url, data, config).then(function (response) {
				 $scope.success = true;
				    $scope.error = false;
				    $scope.successMessage = 'successful';
				    $scope.form_data = {};
				    console.log('done');
				    $scope.closeModal();
				    fetchData();
			}, function (response) {
				 $scope.success = false;
				    $scope.error = true;
				    $scope.errorMessage = 'error...!';
			});
			
			$scope.firstname = "";
			$scope.lastname = "";
	  }
});