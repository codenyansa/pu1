App.controller('docController',
    ['$scope', '$rootScope','docService','$http', function($scope, $rootScope, docService, $http) {
      console.log("in docController")
    
        $scope.file = '';

        $scope.upload = function(){
            var file = $scope.file;
            var url = 'upload';
            docService.saveDoc(file)
                .then(
                    function (response) {
                        alert("file uploaded successfully.");
                        $http.get(url).then(function (response) {
                         
                                $rootScope.docList = response;
                                console.log( "docList"+$rootScope.docList)
                            });
                    },
                    function (errResponse) {

                    }
                );
        }
    }
    ]);

App.constant('urls', {
    DOC_URL: 'http://localhost:8088/doc/'
});

App.directive('fileModel', [ '$parse', function($parse) {
    return {
        restrict : 'A',
        link : function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function() {
                scope.$apply(function() {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
} ]);

App.run(function($rootScope, $http) {
    $http.get('http://localhost:8088/doc/').then(
        function(response) {
            $rootScope.docList = response;
        });
    
 
});
