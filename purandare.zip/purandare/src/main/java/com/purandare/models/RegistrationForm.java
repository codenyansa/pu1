package com.purandare.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="filesupload")
public class RegistrationForm {

	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="email")
	private String email;
	
	@Column(name="files")
	private MultipartFile [] albums;

	public RegistrationForm(String name, String email, MultipartFile[] albums) {
		super();
		this.name = name;
		this.email = email;
		this.albums = albums;
	}

	public RegistrationForm() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public MultipartFile[] getAlbums() {
		return albums;
	}

	public void setAlbums(MultipartFile[] albums) {
		this.albums = albums;
	}
	
 
	
}
