package com.purandare.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="files_new")
public class FileUploadMetaData
{
	
	@Column(name="file_id")
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private long id;

	@Column(name="file_name")
	private String file_name;
	
	@Column(name="content_type")
	private String contentType;
	
	
	@Column(name = "file_details")
	private String file_details;
	


	public FileUploadMetaData(long id, String file_name, String contentType, String file_details) {
		super();
		this.id = id;
		this.file_name = file_name;
		this.contentType = contentType;
		this.file_details = file_details;
	}
	
	


	public FileUploadMetaData(String file_name, String contentType, String file_details) {
		super();
		this.file_name = file_name;
		this.contentType = contentType;
		this.file_details = file_details;
	}


	public FileUploadMetaData() {
		super();
		// TODO Auto-generated constructor stub
	}




	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	
	public String getFile_name() {
		return file_name;
	}


	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}


	public String getContentType() {
		return contentType;
	}


	public void setContentType(String contentType) {
		this.contentType = contentType;
	}


	public String getFile_details() {
		return file_details;
	}


	public void setFile_details(String file_details) {
		this.file_details = file_details;
	}




	@Override
	public String toString() {
		return "FileUploads [id=" + id + ", file_name=" + file_name + ", contentType=" + contentType + ", file_details="
				+ file_details + "]";
	}
	
	

}
