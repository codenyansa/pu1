package com.purandare.models;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Eventss")
public class Eventss {
	
   @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private long event_id;

	@Column(name = "event_title")
	private String event_title;
	
	@Column(name = "event_loaction")
	private String event_loaction;
	

	@Column(name = "dateOfInsert")
	private Date dateOfInsert;

	@Column(name = "start_time")
	private Date start_time;

	@Column(name = "end_time")

	private Date end_time;

	
	@Column(name = "event_details")
	private String event_details;
	
	@Lob
	@Column(name = "file")
	private byte[] file;

	@Lob
	@Column(name = "pic2")
	private byte[] pic2;

	public Eventss() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Eventss(long event_id, String event_title, String event_loaction, Date dateOfInsert, Date start_time,
			Date end_time, String event_details, byte[] file, byte[] pic2) {
		super();
		this.event_id = event_id;
		this.event_title = event_title;
		this.event_loaction = event_loaction;
		this.dateOfInsert = dateOfInsert;
		this.start_time = start_time;
		this.end_time = end_time;
		this.event_details = event_details;
		this.file = file;
		this.pic2 = pic2;
	}

	public Eventss(String event_title, String event_loaction, Date dateOfInsert, Date start_time, Date end_time,
			String event_details, byte[] file, byte[] pic2) {
		super();
		this.event_title = event_title;
		this.event_loaction = event_loaction;
		this.dateOfInsert = dateOfInsert;
		this.start_time = start_time;
		this.end_time = end_time;
		this.event_details = event_details;
		this.file = file;
		this.pic2 = pic2;
	}
	
	

	public Eventss(String event_title, String event_loaction, Date dateOfInsert, Date start_time, Date end_time,
			String event_details, byte[] file) {
		super();
		this.event_title = event_title;
		this.event_loaction = event_loaction;
		this.dateOfInsert = dateOfInsert;
		this.start_time = start_time;
		this.end_time = end_time;
		this.event_details = event_details;
		this.file = file;
	}

	public long getEvent_id() {
		return event_id;
	}

	public void setEvent_id(long event_id) {
		this.event_id = event_id;
	}

	public String getEvent_title() {
		return event_title;
	}

	public void setEvent_title(String event_title) {
		this.event_title = event_title;
	}

	public String getEvent_loaction() {
		return event_loaction;
	}

	public void setEvent_loaction(String event_loaction) {
		this.event_loaction = event_loaction;
	}

	public Date getDateOfInsert() {
		return dateOfInsert;
	}

	public void setDateOfInsert(Date dateOfInsert) {
		this.dateOfInsert = dateOfInsert;
	}

	public Date getStart_time() {
		return start_time;
	}

	public void setStart_time(Date start_time) {
		this.start_time = start_time;
	}

	public Date getEnd_time() {
		return end_time;
	}

	public void setEnd_time(Date end_time) {
		this.end_time = end_time;
	}

	public String getEvent_details() {
		return event_details;
	}

	public void setEvent_details(String event_details) {
		this.event_details = event_details;
	}

	public byte[] getFile() {
		return file;
	}

	public void setFile(byte[] file) {
		this.file = file;
	}

	public byte[] getPic2() {
		return pic2;
	}

	public void setPic2(byte[] pic2) {
		this.pic2 = pic2;
	}

	@Override
	public String toString() {
		return "Eventss [event_id=" + event_id + ", event_title=" + event_title + ", event_loaction=" + event_loaction
				+ ", dateOfInsert=" + dateOfInsert + ", start_time=" + start_time + ", end_time=" + end_time
				+ ", event_details=" + event_details + ", file=" + Arrays.toString(file) + ", pic2="
				+ Arrays.toString(pic2) + "]";
	}

  
}
