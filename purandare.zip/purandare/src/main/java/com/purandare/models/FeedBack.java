package com.purandare.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="feedback")
public class FeedBack
{
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long feedback_id;
	
	@Column(name="user_name")
	private String  user_name;
	
	@Column(name="user_email")
	private String user_email;
	
	@Column(name="contact_number")
	private String contact_number;
	
	@Column(name="feedback_details")
	private String feedback_details;
	
	@Column(name="feedback_date")
	private Date feedback_date;

	public FeedBack() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public FeedBack(String user_name, String user_email, String contact_number, String feedback_details,
			Date feedback_date) {
		super();
		this.user_name = user_name;
		this.user_email = user_email;
		this.contact_number = contact_number;
		this.feedback_details = feedback_details;
		this.feedback_date = feedback_date;
	}



	public long getFeedback_id() {
		return feedback_id;
	}



	public void setFeedback_id(long feedback_id) {
		this.feedback_id = feedback_id;
	}



	public String getUser_name() {
		return user_name;
	}



	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}



	public String getUser_email() {
		return user_email;
	}



	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}



	public String getContact_number() {
		return contact_number;
	}



	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}



	public String getFeedback_details() {
		return feedback_details;
	}



	public void setFeedback_details(String feedback_details) {
		this.feedback_details = feedback_details;
	}



	public Date getFeedback_date() {
		return feedback_date;
	}



	public void setFeedback_date(Date feedback_date) {
		this.feedback_date = feedback_date;
	}



	@Override
	public String toString() {
		return "FeedBack [feedback_id=" + feedback_id + ", user_name=" + user_name + ", user_email=" + user_email
				+ ", contact_number=" + contact_number + ", feedback_details=" + feedback_details + ", feedback_date="
				+ feedback_date + "]";
	}



}
