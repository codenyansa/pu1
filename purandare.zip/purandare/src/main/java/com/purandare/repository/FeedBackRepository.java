package com.purandare.repository;

import org.springframework.data.repository.CrudRepository;

import com.purandare.models.FeedBack;

public interface FeedBackRepository extends CrudRepository<FeedBack,Long>
{

}
