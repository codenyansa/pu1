package com.purandare.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.purandare.models.Document;

@Repository
public interface DocumentRepository extends CrudRepository<Document, Long>
{

}
