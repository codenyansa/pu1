package com.purandare.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.purandare.models.RegistrationForm;



@Repository
public interface RegistrationFormRepositoy extends JpaRepository<RegistrationForm, Long>
{

}
