package com.purandare.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.purandare.models.UserLogin;

public interface LoginRepository  extends JpaRepository<UserLogin, Long>
{
	 UserLogin findByUsername(String username);


}
