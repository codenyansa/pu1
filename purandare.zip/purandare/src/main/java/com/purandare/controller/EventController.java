package com.purandare.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.purandare.models.Eventss;
import com.purandare.repository.EventssRepository;

@RestController
public class EventController 
{
	private final Logger logger = LoggerFactory.getLogger(EventController.class);
	
	@Autowired
	EventssRepository eventRepo;
	

	@RequestMapping(value = "/addEvent", method = RequestMethod.POST)
	public String saveEventsss(@RequestParam("event_title") String event_title, @RequestParam("event_loaction") String event_loaction,
			@RequestParam("start_time") Date start_time,@RequestParam("end_time") Date end_time,@RequestParam("event_details") String event_details,
			@RequestParam("file") MultipartFile file)
	  {
		System.out.println("hello");
		Date date = new Date();
		 if (!file.isEmpty())
	        {
	            try 
	            {
				byte[] bytes = file.getBytes();
				
				eventRepo.save(new Eventss(event_title,event_loaction,date,start_time,end_time,event_details,file.getBytes()));
	          	/*eventRepo.save(new Eventss(eventss.getEvent_title(),eventss.getEvent_loaction(),date, eventss.getStart_time(), eventss.getEnd_time(),
				eventss.getEvent_details(),file.getBytes(),eventss.getPic2()));  @DateTimeFormat(pattern="yyyy-MM-dd")*/
	          	
	            }
	            catch(Exception e)
	            {
	            	e.printStackTrace();
	            }
	           return "success";
	        }
		  else
	        {
	           return "fail";
	       }
		
	}
	
	@RequestMapping(value = "/allEventsList")
	public List<Eventss> getEventss() 
	{

		System.out.println( "in test value");
		
		List<Eventss> eventssList = (List<Eventss>) eventRepo.findAll();
		

		
		System.out.println("in getEventss() "+eventssList.iterator());
		return eventssList;
	}
	
	/*
	 @RequestMapping(value = "/upload", method = RequestMethod.POST)
	    public @ResponseBody Eventss handleFileUpload(@RequestParam(value="file") MultipartFile file) throws IOException {
	        return eventRepo.save(file);
	    }
	 
	 @RequestMapping(value = "/fileupload", method = RequestMethod.POST)
		public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile uploadfile,
				final HttpServletRequest request) {
		 

			if (uploadfile.isEmpty()) {
				return new ResponseEntity<String>("please select a file!", HttpStatus.OK);
			}

			try {
				
				//eventRepo.save();
				*//** File will get saved to file system and database *//*
				//saveUploadedFiles(Arrays.asList(uploadfile));
			} catch (IOException e) {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
	 }

	    // Upload Logic
	}
	

*/
	   // GET: Show upload form page.
	  
	
	// POST: Do Upload
	  /* @RequestMapping(value = "/uploadEvent", method = RequestMethod.POST)
	   public String uploadOneFileHandlerPOST(HttpServletRequest request, Model model,
			   @ModelAttribute("myUploadForm") Eventss myUploadForm,@RequestBody Eventss events) {
		   eventRepo.save(events);
	      return this.doUpload(request, model, myUploadForm);
	 
	   }
	   private String doUpload(HttpServletRequest request, Model model, //
			   Eventss myUploadForm) {
		 
		      String description = myUploadForm.getDescription();
		      System.out.println("Description: " + description);
		 
		      // Root Directory.
		      String uploadRootPath = request.getServletContext().getRealPath("upload");
		      System.out.println("uploadRootPath=" + uploadRootPath);
		 
		      File uploadRootDir = new File(uploadRootPath);
		      // Create directory if it not exists.
		      if (!uploadRootDir.exists()) {
		         uploadRootDir.mkdirs();
		      }
		      MultipartFile[] fileDatas = myUploadForm.getFileDatas();
		      //
		      List<File> uploadedFiles = new ArrayList<File>();
		      List<String> failedFiles = new ArrayList<String>();
		 
		      for (MultipartFile fileData : fileDatas) {
		 
		         // Client File Name
		         String name = fileData.getOriginalFilename();
		         System.out.println("Client File Name = " + name);
		 
		         if (name != null && name.length() > 0) {
		            try {
		               // Create the file at server
		               File serverFile = new File(uploadRootDir.getAbsolutePath() + File.separator + name);
		 
		               BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
		               stream.write(fileData.getBytes());
		               stream.close();
		               //
		               uploadedFiles.add(serverFile);
		               System.out.println("Write file: " + serverFile);
		            } catch (Exception e) {
		               System.out.println("Error Write file: " + name);
		               failedFiles.add(name);
		            }
		         }
		      }
		   
		      model.addAttribute("uploadedFiles", uploadedFiles);
		      model.addAttribute("failedFiles", failedFiles);
		      return "uploadResult";
		   }
	
	*/

	/*@RequestMapping(value = "/uploadEvent", method = RequestMethod.POST)
	public ResponseEntity<?> uploadFile(@RequestParam("name") String name,@RequestParam("event_id") MultipartFile uploadfile,
			final HttpServletRequest request) {
		
		System.out.println("in controller of fileupload");

		*//** Below data is what we saving into database *//*
		logger.debug("Single file upload!");
		logger.debug("fileName : " + uploadfile.getOriginalFilename());
		logger.debug("contentType : " + uploadfile.getContentType());
		logger.debug("contentSize : " + uploadfile.getSize());
		
		

		if (uploadfile.isEmpty()) {
			return new ResponseEntity<String>("please select a file!", HttpStatus.OK);
		}

		try {
		//** File will get saved to file system and database *//*
			saveUploadedFiles(Arrays.asList(uploadfile));
			
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<String>("Successfully uploaded - " + uploadfile.getOriginalFilename(),
				new HttpHeaders(), HttpStatus.OK);

	}
	*/
	/*//**
	 * Files will get saved to file system and database
	 * @param files
	 * @throws IOException
	 *//*
	private void saveUploadedFiles(List<MultipartFile> files) throws IOException {
		for (MultipartFile file : files) {
			if (file.isEmpty()) {
				continue; 
			}
			byte[] bytes = file.getBytes();
			
			//saveEvents(file);

		}

	}*/

	



	

}
