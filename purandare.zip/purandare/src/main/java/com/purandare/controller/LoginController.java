package com.purandare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import java.util.Optional;
import com.purandare.models.UserLogin;
import com.purandare.repository.LoginRepository;

@RestController
public class LoginController
{
	@Autowired
	LoginRepository loginRepo;
	
	
	/*    @RequestMapping(value = "/login", method = RequestMethod.POST)
	    public ModelAndView login(@ModelAttribute("userLoginForm") UserLogin userLoginForm, Model model)
	    {
		 
		 Optional<UserLogin> complianceOptional = loginRepo.findByUsername(userLoginForm.getUsername());
	
		 if (!complianceOptional.isPresent())
			{
				model.addAttribute("error", "error...!");
				 return new ModelAndView("login");
			}
			else
			{
	            model.addAttribute("message", "You have been login successfully.");
	            model.addAttribute("id", userLoginForm.getUsername());
	            return new ModelAndView("welcome");
			}
	        //return "";
	  }  */ 
	    
	    
	    @RequestMapping(value = "/login", method = RequestMethod.POST)
	    public ModelAndView login(@ModelAttribute("userForm") UserLogin userForm, Model model) 
	    {
	    	UserLogin complianceOptional = loginRepo.findByUsername(userForm.getUsername());
		// Optional<User> complianceOptional = repository.findByUsername1(userForm.getUsername());
	    	System.out.println("User Name="+userForm.getUsername());
		  if (complianceOptional.getId() == null)
			{
				model.addAttribute("error", "error...!");
				 return new ModelAndView("login");
			}
			else
			{
	            model.addAttribute("message", "You have been login successfully.");
	            model.addAttribute("username", userForm.getUsername());
	            model.addAttribute("id", complianceOptional.getId());
	            return new ModelAndView("addEventss");
			}
	        //return "";
	    }
	    

	    

}
