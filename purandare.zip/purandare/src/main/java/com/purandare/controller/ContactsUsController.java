package com.purandare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.purandare.models.ContactsUs;
import com.purandare.repository.ContactUsRepository;

@RestController
public class ContactsUsController 
{
	@Autowired
	ContactUsRepository contactrepo;
	
	@RequestMapping(value="/messagesend", method = RequestMethod.POST)
	public void saveMessage(@RequestBody ContactsUs contactsus)
	{
		System.out.println(contactsus.getFirst_name());
		contactrepo.save(contactsus);
	}

}
