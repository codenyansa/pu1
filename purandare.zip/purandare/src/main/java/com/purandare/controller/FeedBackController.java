package com.purandare.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;

import com.purandare.models.FeedBack;
import com.purandare.repository.FeedBackRepository;

@RestController
public class FeedBackController 
{
	@Autowired
	FeedBackRepository feedbackrepo;
	
	@RequestMapping(value="/savefeedback",  method=RequestMethod.POST)
	public void saveFeedBack(@RequestBody FeedBack feedback)
	{
		//String user_name, String user_email, String contact_number, String feedback_details,
		//Date feedback_date
		Date date = new Date();
		System.out.println(feedback.getUser_name());
		feedbackrepo.save(new FeedBack(feedback.getUser_name(),feedback.getUser_email(),feedback.getContact_number(),feedback.getFeedback_details(),date));
		
	}
	
	
	@RequestMapping(value = "/allfeedbacks")
	public List<FeedBack> getResource() 
	{

		System.out.println( "in allfeedbacks value");
		List<FeedBack> feebbacktList = (List<FeedBack>) feedbackrepo.findAll();

		return feebbacktList;
	}
	
	

}
