package com.purandare.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.purandare.models.UserLogin;

@Controller
public class HomeController 
{
	@RequestMapping("/index")
	public String index()
	{
		return "index";
	}
	
	
    @RequestMapping("/form")
	public String addfiles()
	{
	  System.out.println("in about singleFileUpload");
		return "welcome";
		
	}
	
	@RequestMapping("/login")
	 public String logins(Model model) 
	{
		  System.out.println("in Userlogin homecontroller");
		 model.addAttribute("userLoginForm", new UserLogin());
		return "login";	
	}
	
	@RequestMapping("/about")
	public String about()
	{
	  System.out.println("in about homecontroller");
		return "about";
		
	}
	
	@RequestMapping("/eventss")
	public String eventss()
	{
		return "eventss";
	}
	
	@RequestMapping("/eventsingle")
	public String eventsingle()
	{
		return "event-single";
	}
	
	

	@RequestMapping("/gallery")
	public String gallerys()
	{
		return "gallery";
	}
	
	@RequestMapping("/blog")
	public String blog()
	{
		return "blog";
	}
	
	@RequestMapping("/blog-single")
	public String singleBlog()
	{
		return "blog-single";
	}
	
	@RequestMapping("/contactus")
	public String contactuss()
	{
		return "contactus";
	}
	
	@RequestMapping("/addEvent")
	public String adminEvents()
	{
		return "addEventss";
	}
	
	@RequestMapping("/feedbacks")
	public String feedBackurl()
	{
		return "feedback1";
	}
	
	@RequestMapping("/galleryupload")
	public String galleryUpload()
	{
		return "fileUpload";
	}
	

	@RequestMapping("/testdemo")
	public String testfileupload()
	{
		return "test1";
	}
	@RequestMapping("/TestEvent")
	public String testEvent()
	{
		return "adminEventss";
	}
	
	@RequestMapping("/addgallery")
	public String addgallery()
	{
		return "addgallery";
	}

	@RequestMapping("/uploadfile")
	public String test()
	{
		return "angularfileupload";
	}
	
	@RequestMapping("/testupload")
	public String test11()
	{
		return "document";
	}
	
	

	

	/*@RequestMapping(/)
	public String index() {
		return "upload";
	}*/

	
 

	
	
	
	

}
